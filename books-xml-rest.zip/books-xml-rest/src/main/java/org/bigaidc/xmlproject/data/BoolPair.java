package org.bigaidc.xmlproject.data;

public class BoolPair<T> {
	public T _E = null;
	public boolean isE = false;
}
