package org.bigaidc.xmlproject.data;

import java.util.TreeMap;

public class DomainMap extends TreeMap<Integer, DomainObj> {

}
