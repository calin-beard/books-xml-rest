package org.bigaidc.xmlproject.types;

/**
 * Created by tdonohue on 07/03/2018.
 */
public class PostRequestType {

    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
